var app = require('express')();
var express = require('express');
var http = require('http').Server(app);
//require('jquery-colpick');
var io = require('socket.io')(http);
var paper = require('paper');

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/paperoids.html');
});

app.use(express.static('public'));
app.use('/paper', express.static(__dirname + '/node_modules/paper/dist/'));
app.use('/js', express.static(__dirname + '/node_modules/'));

http.listen(3000, function() {
    console.log('listening on *:3000');
});

/** Game Serve logic **/

var LIFES = 3; // Lifes per player
var ASTEROIDS = 10; // Number of Asteroids on screen
var SHOT_DELAY = 12; // delay between shots
var SHOT_SPEED = 4; // How many px does a shot move per tick
var SHOT_LIFESPAN = 60; // How long a shot lives

var SHIP_TOPSPEED = 20; // Topspeed of ship
var SHIP_ACCELERATION = 5; // Acceleration of ship
var SHIP_TURNRATE = 3; // Turnrate of ship

/** Receive movement of ships
 *  Receive new shots
 *
 *  Update position of ships, asteroids, shots
 *
 *  Check collision
 *
 *  Game logic like killing and respawning stuff
 */

io.on('connection', function(socket) {
    console.log('a user connected! | ' + socket);

    socket.on('new player', function(player) {

        player = JSON.parse(player);
        console.log(player);
        // Add new player to shiplist
        console.log('new player "' + player.name + '" connected.');
        console.log(player.ship);



        // ships obj: id, color, movement, pos.x, pos.y, pos.angle
        // Add ship for new player
        var ship = {
            id: socket.id,
            color: player.color,
            name: player.name,
            //This gets passed as array
            group: player.ship,
            movement: {
                up: false,
                down: false,
                left: false,
                right: false,
                shooting: false
            },
            pos: {
                x: 500,
                y: 100
            },
            angle: 0,
            speed: 0
        };

        game.addShip(ship);

        socket.emit('acknowledge new player');
        socket.emit('game state players', game.ships);
        socket.broadcast.emit('game add player', ship);
        console.log(ship.group);

    });

    socket.on('player movement', function(movement) {
        //console.log('received player ' + socket.id + ' movement: ' + movement.up + ' ' + movement.down + ' ' + movement.left + ' ' + movement.right + ' ' + movement.shooting);

        // Update player movement
        game.updateShip(socket.id, movement);


    });


    socket.on('disconnect', function() {
        // Delete player stuff
        // Ship, shots, color
        game.removeShip(socket.id);
        console.log('player disconnected.');
    })
});

function GameServer(){
    // ships obj: id, color, movement, pos.x, pos.y, pos.angle
    this.ships = [];

    // shots obj: owner-id, color, pos.x, pos.y, angle
    this.shots = [];

    this.lastShotId = 0;

    // asteroids obj: asteroid-id, owner-id, color, pos.x, pos.y, movement
    this.asteroids = [];
}

GameServer.prototype = {

    // Add ship on player entrance
    addShip: function(ship) {
        this.ships.push(ship);
        //console.log(ship);
    },

    updateShip: function(shipid, movement) {
        this.ships.forEach(function(ship) {
            if(ship.id == shipid) {

                ship.movement = movement;

                // If shooting: add shot
                // TODO Consider delay
                if(ship.movement.shooting) {

                    //TODO calculate angle & position
                    var shot = {
                        owner: ship.id,
                        color: ship.color,
                        pos: {
                            x: ship.pos.x,
                            y: ship.pos.y
                        },
                        angle: ship.angle,
                        time_to_live: SHOT_LIFESPAN
                    };
                    //this.addShot(shot);
                }

                //console.log('updated ' + ship.id);


            }
        });
    },


    // Add shot
    addShot: function(shot) {
        this.shots.push(shot);
    },


    // Remove ship on player exit
    removeShip: function(shipID) {
        this.ships = this.ships.filter( function(t) { return t.id != shipID })
    },


    // Synchronize ships
    moveShips: function() {
        this.ships.forEach ( function(ship) {

            // Update ship angle
            if(ship.movement.left) {
                ship.angle -= SHIP_TURNRATE;
            }

            if(ship.movement.right) {
                ship.angle += SHIP_TURNRATE;
            }

            // Update ship speed
            if(ship.movement.up) {
                ship.speed = Math.max(SHIP_TOPSPEED);
            }

            // Update ship position (based on speed & angle



        });
    },


    // Synchronize shots
    moveShots: function() {
        // Update shot position
    },

    // Detect shot collision
    detectShotCollision: function() {
        // ...
    },

    moveAsteroids: function() {
        // ...
    },


    update: function() {
        // Update shots;
        this.moveShots();

        // Update ship movement;
        this.moveShips();

        // Update Asteroid movement;
        this.moveAsteroids();

        // Check for collisions
    },

    checks: function() {
        //checkCollisions
        this.checkCollisions();

        //checkHits
        this.checkHits();
    },

    //Check if any ship is colliding with asteroids
    checkCollisions: function() {

    },

    //Check if any shot is colliding with ships or asteroids
    checkHits: function() {

    },

    //Send data to clients
    //See "Optimisations" in trello list for possible improvements over sending game state
    sendData: function() {

    }

    //destroy
};

game = new GameServer();

setInterval(function() {
    game.update();
    game.checks();
    game.sendData();
}, 1000 / 60);